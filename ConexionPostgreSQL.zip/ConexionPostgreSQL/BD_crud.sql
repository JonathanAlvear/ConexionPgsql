CREAT TABLE CUENTAS(
	ID SERIAL,
	NOMBRE_USUARIO CHARACTER (50),
	NUMERO_CUENTA INT,
	CAPITAL INT, PRIMARY KEY(ID);
)

SELECT * FROM CUENTAS

CREATE OR REPLACE FUNCTION public.crudcuentas2(
	e_accion integer,
	e_nom_usua character,
	e_num_cuenta character,
	e_capital integer)
    RETURNS character
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE 
AS $BODY$
	DECLARE 
	mensaje character (40);
	BEGIN
	
	CASE
	WHEN (e_accion = 1)THEN
		insert into cuentas(nombre_usuario,numero_cuenta,capital)
			VALUES (e_nom_usua,e_num_cuenta,e_capital);
				mensaje ='Datos registrados exitosamente'; 
	WHEN (e_accion = 2)THEN	
			delete from cuentas where numero_cuenta = e_num_cuenta;
				mensaje ='Datos eliminados exitosamente'; 
	when (e_accion = 3)then
		update cuentas set nombre_usuario= e_nom_usua, capital= e_capital
				where numero_cuenta = e_num_cuenta;
				mensaje ='Datos Actualizados exitosamente'; 
	else
	mensaje := 'Verificar Datos';
	END CASE;
	return mensaje;
	end;
	$BODY$;
	-- 1 = ingresar nueva informacion
	--	2 = eliminar
	-- 3= actualizar
	SELECT crudcuentas2(1,'jonathan','17189589',500)
	