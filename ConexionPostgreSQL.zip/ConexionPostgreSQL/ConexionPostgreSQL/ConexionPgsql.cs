﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows.Forms;
using System.Data;
using NuGet.Protocol.Plugins;
using System.Runtime.InteropServices;

namespace ConexionPostgreSQL
{
   
    class ConexionPgsql
    {
        NpgsqlConnection conn = new NpgsqlConnection("Username = postgres; Password = 1234; Host = localhost; Port = 5432; Database = tarea");

        //conectar
        public void Conectar()
        {
            conn.Open();
            MessageBox.Show("Listo");
        }
        //desconectar
        public void Desconectar()
        {
            conn.Close();
            MessageBox.Show("Cerrado");

        }

        //transaccion exitosa
        /*
        public void transaccionExitosa(float nro_cuenta, float saldo)
        {
            
            try
            {
                conn.Open();
                NpgsqlCommand command = new NpgsqlCommand("UPDATE cuentas SET saldo =" + "'" + saldo + "'" + " - " + "'" + textBox3 + "'" + "Where numero_cuenta =" + "'" + nro_cuenta + "'" + textBox1 + "'", conn);
                //UPDATE usuarios SET saldo_cuenta = saldo_cuenta - 10.00 WHERE numero_cuenta = 314252639044;
                NpgsqlCommand command1 = new NpgsqlCommand("UPDATE cuentas SET saldo =" + "'" + saldo + "'" + " + " + "'" + textBox3 + "'" + "Where numero_cuenta =" + "'" + nro_cuenta + "'" + textBox2 + "'", conn);
                //UPDATE usuarios SET saldo_cuenta = saldo_cuenta + 10.00 WHERE numero_cuenta = 893746194753;
                conn.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show("ERROR:" + error.Message);
            }
        }
        */
        internal void editarUsuario(string v1, ulong v2, float v3)
        {
            throw new NotImplementedException();
        }

        internal void eliminarUsuario(string v1, ulong v2, float v3)
        {
            throw new NotImplementedException();
        }

        //clase aparte
        public DataTable llenaTabla()
        {
            conn.Open();
            string ingresar = $"SELECT * from cuentas;";
            NpgsqlCommand insertarEnBase = new NpgsqlCommand(ingresar, conn);
            NpgsqlDataAdapter datos = new NpgsqlDataAdapter(ingresar, conn);
            DataTable table = new DataTable();
            datos.Fill(table);
            conn.Close();
            return table;

        }


        public void insertarUsuario(string nombre_usuario, int nuevo_numero_cuenta, float capital)
        {
            this.Conectar();
            //string crud_op = $"BEGIN;";
            string ingresar = $"SELECT crudcuentas2('1',\'{nombre_usuario}\',{nuevo_numero_cuenta}, {capital});";
            NpgsqlCommand insertarEnBase = new NpgsqlCommand(ingresar, conn);
            insertarEnBase.ExecuteNonQuery();
            this.Desconectar();
        }


        public void editarUsuario(string nombre_usuario, int nuevo_numero_cuenta, float capital)
        {
            this.Conectar();
            //string crud_op = $"BEGIN;";
            string ingresar = $"SELECT crudcuentas2('3',\'{nombre_usuario}\', {nuevo_numero_cuenta}, {capital});";
            NpgsqlCommand insertarEnBase = new NpgsqlCommand(ingresar, conn);
            insertarEnBase.ExecuteNonQuery();
            this.Desconectar();
        }


        public void eliminarUsuario(string nombre_usuario, int nuevo_numero_cuenta, float capital)
        {
            this.Conectar();
            //string crud_op = $"BEGIN;";
            string sent_delet = $"SELECT crudcuentas2('2',\'{nombre_usuario}\', {nuevo_numero_cuenta}, {capital});";
            NpgsqlCommand exe_delet = new NpgsqlCommand(sent_delet, conn);
            exe_delet.ExecuteNonQuery();
            this.Desconectar();
        }



    }
}
